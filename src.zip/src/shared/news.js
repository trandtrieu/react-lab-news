export const NEWS = [
  {
    id: 0,
    name: "Covid",
    image: "/assets/images/F9E9AE35-D2D2-49B5-BDA9-7652B2F39111.jpeg",
    category: "mains",
    label: "Hot",
    price: "4.99",
    featured: true,
    description:
      "A unique combination of Indian Uthappam (pancake) and Italian pizza, topped with Cerignola olives, ripe vine cherry tomatoes, Vidalia onion, Guntur chillies and Buffalo Paneer.",
  },
  {
    id: 1,
    name: "Tin bóng đá",
    image: "/assets/images/lich-thi-dau-bong-da.jpg",
    category: "mains",
    label: "Hot",
    price: "4.99",
    featured: true,
    description: "regsergrgr",
  },
];
